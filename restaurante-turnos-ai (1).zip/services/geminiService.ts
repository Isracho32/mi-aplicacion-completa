import { GoogleGenAI, Type } from "@google/genai";
import { Employee } from "../types";

const apiKey = process.env.API_KEY;

// Initialize the client only if the key exists to avoid immediate errors, 
// though we handle the missing key in the function call.
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

interface GeneratedShift {
  employeeId: string;
  date: string;
  startTime: string;
  endTime: string;
}

export const generateScheduleWithAI = async (
  employees: Employee[],
  weekStart: string, // YYYY-MM-DD
  requirements: string
): Promise<GeneratedShift[]> => {
  if (!ai) {
    throw new Error("API Key no configurada.");
  }

  const model = ai.models;
  
  const prompt = `
    Genera un horario semanal de trabajo para un restaurante.
    
    Inicio de semana: ${weekStart} (Sábado).
    Genera turnos para 7 días (Sábado a Viernes).
    
    Empleados disponibles (JSON):
    ${JSON.stringify(employees.map(e => ({ id: e.id, name: e.name, role: e.role, maxHours: e.maxHoursPerWeek })))}

    Requisitos especiales del usuario:
    ${requirements}

    Reglas generales:
    - Los turnos de almuerzo suelen ser 12:00-16:00.
    - Los turnos de cena suelen ser 19:00-23:00 o 20:00-00:00.
    - Respeta las horas máximas de cada empleado.
    - Asegúrate de que haya al menos 1 Chef y 1 Camarero en cada turno principal (almuerzo/cena).
  `;

  try {
    const response = await model.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              employeeId: { type: Type.STRING },
              date: { type: Type.STRING, description: "Format YYYY-MM-DD" },
              startTime: { type: Type.STRING, description: "Format HH:mm" },
              endTime: { type: Type.STRING, description: "Format HH:mm" }
            },
            required: ["employeeId", "date", "startTime", "endTime"]
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    
    return JSON.parse(jsonText) as GeneratedShift[];

  } catch (error) {
    console.error("Error generating schedule:", error);
    throw error;
  }
};