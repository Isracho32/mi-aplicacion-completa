
import React, { useState } from 'react';
import { Calendar, Wand2, Plus, X, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { format, addDays, startOfWeek, isSameDay, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { Employee, Shift, EmployeeRole } from '../types';
import { getRoleColor } from '../constants';
import { generateScheduleWithAI } from '../services/geminiService';

interface ScheduleProps {
  employees: Employee[];
  shifts: Shift[];
  onAddShift: (shift: Shift) => void;
  onRemoveShift: (id: string) => void;
  onBulkAddShifts: (shifts: Shift[]) => void;
}

export const Schedule: React.FC<ScheduleProps> = ({ 
  employees, 
  shifts, 
  onAddShift, 
  onRemoveShift,
  onBulkAddShifts
}) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Helper to get the week's days (Sat-Fri)
  // weekStartsOn: 6 means Saturday
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 6 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const handleGenerateAI = async () => {
    setIsGenerating(true);
    setAiError(null);
    try {
      const generatedShifts = await generateScheduleWithAI(
        employees, 
        format(weekStart, 'yyyy-MM-dd'),
        aiPrompt
      );

      // Convert generated raw data to proper Shift objects with IDs
      const newShifts: Shift[] = generatedShifts.map(s => ({
        id: crypto.randomUUID(),
        employeeId: s.employeeId,
        date: s.date,
        startTime: s.startTime,
        endTime: s.endTime
      }));

      onBulkAddShifts(newShifts);
      setIsAiModalOpen(false);
    } catch (e) {
        setAiError("Hubo un error al generar el horario. Verifica tu API Key o intenta de nuevo.");
    } finally {
      setIsGenerating(false);
    }
  };

  const nextWeek = () => setCurrentDate(addDays(currentDate, 7));
  const prevWeek = () => setCurrentDate(addDays(currentDate, -7));

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4 bg-white p-2 rounded-lg shadow-sm border border-orange-100">
          <button onClick={prevWeek} className="p-2 hover:bg-orange-50 rounded-md text-slate-600">
            <ChevronLeft size={20} />
          </button>
          <span className="font-semibold text-slate-700 min-w-[200px] text-center capitalize">
            {format(weekStart, 'MMMM yyyy', { locale: es })}
          </span>
          <button onClick={nextWeek} className="p-2 hover:bg-orange-50 rounded-md text-slate-600">
            <ChevronRight size={20} />
          </button>
        </div>

        <button 
          onClick={() => setIsAiModalOpen(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-orange-500 text-white px-5 py-2.5 rounded-lg shadow-md hover:shadow-lg transition-all"
        >
          <Wand2 size={18} />
          <span>Generar con IA</span>
        </button>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-xl shadow-sm border border-orange-100 overflow-hidden overflow-x-auto">
        <div className="min-w-[1000px]">
          {/* Header Row */}
          <div className="grid grid-cols-8 border-b border-orange-100 bg-orange-50/50">
            <div className="p-4 font-semibold text-slate-500 text-sm">Empleado</div>
            {weekDays.map(day => (
              <div key={day.toString()} className="p-3 text-center border-l border-orange-100">
                <div className="text-xs font-bold text-slate-400 uppercase mb-1">
                  {format(day, 'EEE', { locale: es })}
                </div>
                <div className={`text-sm font-bold ${isSameDay(day, new Date()) ? 'text-red-600' : 'text-slate-700'}`}>
                  {format(day, 'd')}
                </div>
              </div>
            ))}
          </div>

          {/* Rows per Employee */}
          {employees.map(emp => (
            <div key={emp.id} className="grid grid-cols-8 border-b border-orange-50 last:border-0 hover:bg-orange-50/30 transition-colors">
              <div className="p-4 flex flex-col justify-center border-r border-orange-100 bg-white sticky left-0 z-10">
                <div className="font-semibold text-slate-800 text-sm">{emp.name}</div>
                <div className="text-xs text-slate-500">{emp.role}</div>
              </div>
              {weekDays.map(day => {
                const dayStr = format(day, 'yyyy-MM-dd');
                const dayShifts = shifts.filter(s => s.employeeId === emp.id && s.date === dayStr);

                return (
                  <div key={dayStr} className="p-2 min-h-[80px] border-l border-orange-100 relative group">
                    {dayShifts.map(shift => (
                      <div 
                        key={shift.id} 
                        className={`text-xs p-2 rounded mb-1 relative group/shift border ${getRoleColor(emp.role)}`}
                      >
                        <div className="font-bold">{shift.startTime} - {shift.endTime}</div>
                         <button 
                            onClick={() => onRemoveShift(shift.id)}
                            className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover/shift:opacity-100 transition-opacity"
                          >
                            <X size={10} />
                          </button>
                      </div>
                    ))}
                    
                    {/* Add Button (Hidden by default, shown on hover) */}
                    <button 
                      onClick={() => {
                        const startT = '09:00';
                        const endT = '17:00';
                        onAddShift({
                          id: crypto.randomUUID(),
                          employeeId: emp.id,
                          date: dayStr,
                          startTime: startT,
                          endTime: endT
                        });
                      }}
                      className="absolute bottom-1 right-1 p-1 rounded-full bg-slate-200 text-slate-600 opacity-0 group-hover:opacity-100 hover:bg-red-100 hover:text-red-600 transition-all"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* AI Modal */}
      {isAiModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl animate-fade-in-up border-t-4 border-red-500">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-3">
                 <div className="bg-red-100 p-2 rounded-lg text-red-600">
                    <Wand2 size={24} />
                 </div>
                 <div>
                    <h3 className="text-xl font-bold text-slate-800">Generador Automático</h3>
                    <p className="text-xs text-slate-500">Impulsado por Gemini 2.5</p>
                 </div>
              </div>
              <button onClick={() => setIsAiModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-sm text-slate-600">
                Describe los requisitos para esta semana (del Sábado al Viernes).
              </p>
              
              <textarea
                className="w-full h-32 border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-red-500 outline-none resize-none text-sm"
                placeholder="Ej: Necesito 2 camareros extra el Sábado por la noche..."
                value={aiPrompt}
                onChange={e => setAiPrompt(e.target.value)}
              />

              {aiError && (
                 <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg border border-red-100">
                    {aiError}
                 </div>
              )}
              
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setIsAiModalOpen(false)}
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleGenerateAI}
                  disabled={isGenerating}
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-red-600 to-orange-500 text-white rounded-xl hover:shadow-lg font-medium flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      <span>Pensando...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 size={20} />
                      <span>Generar Horario</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
