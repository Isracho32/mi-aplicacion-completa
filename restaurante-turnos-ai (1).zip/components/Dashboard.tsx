
import React, { useState, useRef } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Share2, AlertCircle, Download, X, Banknote, UtensilsCrossed, Trash2, Calendar } from 'lucide-react';
import { Employee, Shift, Discount } from '../types';
import { getRoleColorHex } from '../constants';
import html2canvas from 'html2canvas';

interface DashboardProps {
  employees: Employee[];
  shifts: Shift[];
  discounts: Discount[];
  onAddDiscount: (d: Discount) => void;
  onRemoveDiscount: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  employees, 
  shifts, 
  discounts, 
  onAddDiscount, 
  onRemoveDiscount 
}) => {
  const [transportRate, setTransportRate] = useState<number>(10);
  
  // Modal states
  const [selectedEmployeeForDiscount, setSelectedEmployeeForDiscount] = useState<string | null>(null);
  const [tempDiscount, setTempDiscount] = useState<{amount: string, reason: string, date: string}>({ 
    amount: '', 
    reason: '',
    date: new Date().toISOString().split('T')[0]
  });
  
  // Changed to store ID to always get fresh data
  const [ticketEmployeeId, setTicketEmployeeId] = useState<string | null>(null);
  const ticketRef = useRef<HTMLDivElement>(null);

  // Calculate stats
  const employeeStats = employees.map(emp => {
    const empShifts = shifts.filter(s => s.employeeId === emp.id);
    let totalHours = 0;
    let shiftCostTotal = 0;
    
    const uniqueDays = new Set(empShifts.map(s => s.date)).size;

    empShifts.forEach(s => {
      // Calculate hours with full precision based on minutes
      const start = parseInt(s.startTime.split(':')[0]) + (parseInt(s.startTime.split(':')[1]) / 60);
      const end = parseInt(s.endTime.split(':')[0]) + (parseInt(s.endTime.split(':')[1]) / 60);
      
      let duration = end - start;
      if (duration < 0) duration += 24;
      
      totalHours += duration;

      // COST CALCULATION
      if (emp.paymentType === 'HOURLY') {
        // RULE: < 3.5h = All Overtime Rate. >= 3.5h = 3.5 Base + Rest Overtime
        if (duration < 3.5) {
          shiftCostTotal += duration * emp.hourlyRateOvertime;
        } else {
          const baseHours = 3.5;
          const extraHours = duration - 3.5;
          shiftCostTotal += (baseHours * emp.hourlyRateBase) + (extraHours * emp.hourlyRateOvertime);
        }
      }
    });

    // If Monthly, calculate proportional salary based on days worked
    // (Monthly Salary / 30) * Days Worked
    if (emp.paymentType === 'MONTHLY') {
        const dailyRate = (emp.monthlySalary || 0) / 30;
        shiftCostTotal = dailyRate * uniqueDays;
    }

    const transportTotal = uniqueDays * transportRate;
    
    // Sum all discounts for this employee
    const empDiscounts = discounts.filter(d => d.employeeId === emp.id);
    const totalDiscountAmount = empDiscounts.reduce((sum, d) => sum + d.amount, 0);

    const totalPay = shiftCostTotal + transportTotal - totalDiscountAmount;

    return {
      id: emp.id,
      name: emp.name.split(' ')[0], 
      fullName: emp.name,
      // Precision update: 2 decimal places for hours to capture minutes/half-minutes accurately in display
      hours: parseFloat(totalHours.toFixed(2)),
      salaryCost: parseFloat(shiftCostTotal.toFixed(2)),
      transportCost: transportTotal,
      discounts: empDiscounts,
      totalDiscountAmount: totalDiscountAmount,
      totalCost: parseFloat(totalPay.toFixed(2)),
      daysWorked: uniqueDays,
      role: emp.role,
      paymentType: emp.paymentType,
      monthlySalary: emp.monthlySalary,
      max: emp.maxHoursPerWeek
    };
  });

  const totalWeeklyCost = employeeStats.reduce((acc, curr) => acc + curr.totalCost, 0);

  // Find the full stats object for the selected ticket employee
  const ticketData = ticketEmployeeId ? employeeStats.find(e => e.id === ticketEmployeeId) : null;

  // Handlers
  const handleAddPenalty = () => {
    if (selectedEmployeeForDiscount && tempDiscount.amount && tempDiscount.reason) {
      onAddDiscount({
        id: crypto.randomUUID(),
        employeeId: selectedEmployeeForDiscount,
        date: tempDiscount.date,
        amount: parseFloat(tempDiscount.amount),
        reason: tempDiscount.reason
      });
      setTempDiscount({ ...tempDiscount, amount: '', reason: '' }); // Reset fields but keep date
    }
  };

  const handleDownloadImage = async () => {
    if (ticketRef.current && ticketData) {
      const canvas = await html2canvas(ticketRef.current, {
        backgroundColor: '#fff7ed', 
        scale: 2 
      });
      const image = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.href = image;
      link.download = `Boleta_${ticketData.fullName.replace(/\s+/g, '_')}.png`;
      link.click();
    }
  };

  const handleShareWhatsApp = (stats: typeof employeeStats[0]) => {
    let message = `🧾 *BOLETA DE PAGO - DOÑA CANDY* 🍬%0A` +
      `👤 Empleado: ${stats.fullName}%0A` +
      `--------------------------------%0A` +
      `⏱️ Horas trabajadas: ${stats.hours.toFixed(2)}h%0A` +
      `📅 Turnos: ${stats.daysWorked} días%0A`;
      
    if (stats.paymentType === 'MONTHLY') {
        message += `🗓️ Modalidad: Mensual (Proporcional)%0A`;
        message += `💰 Sueldo Calculado: Bs ${stats.salaryCost.toFixed(2)}%0A`;
    } else {
        message += `💰 Sueldo Base+Extras: Bs ${stats.salaryCost.toFixed(2)}%0A`;
    }
      
    message += `🚌 Pasajes: Bs ${stats.transportCost.toFixed(2)}%0A`;

    if (stats.totalDiscountAmount > 0) {
      const subtotal = stats.salaryCost + stats.transportCost;
      message += `--------------------------------%0A`;
      message += `Subtotal: Bs ${subtotal.toFixed(2)}%0A`;
      message += `⚠️ *DESCUENTOS / MULTAS:* -Bs ${stats.totalDiscountAmount.toFixed(2)}%0A`;
      stats.discounts.forEach(d => {
         message += `   - ${d.reason} (${d.date}): Bs ${d.amount}%0A`;
      });
    }

    message += `--------------------------------%0A`;
    message += `*💵 TOTAL A PAGAR: Bs ${stats.totalCost.toFixed(2)}*`;
    
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  // Helper to find selected emp name
  const getSelectedEmpName = () => {
    return employees.find(e => e.id === selectedEmployeeForDiscount)?.name || '';
  };

  const currentEmpDiscounts = discounts.filter(d => d.employeeId === selectedEmployeeForDiscount);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-orange-100">
          <h3 className="text-sm font-medium text-slate-500">Costo Semanal Total</h3>
          <p className="text-3xl font-bold text-slate-800 mt-2">Bs {totalWeeklyCost.toLocaleString('es-BO', { minimumFractionDigits: 2 })}</p>
          <p className="text-xs text-slate-400 mt-1">Salarios + Pasajes - Multas</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-orange-100">
          <h3 className="text-sm font-medium text-slate-500">Configurar Pasajes</h3>
           <div className="flex items-center gap-2 mt-2">
             <span className="text-sm font-bold text-slate-700">Bs</span>
             <input 
               type="number" 
               min="0"
               value={transportRate}
               onChange={(e) => setTransportRate(Number(e.target.value))}
               className="w-20 border border-slate-300 rounded px-2 py-1 text-lg font-bold text-slate-800 focus:ring-2 focus:ring-red-500 outline-none"
             />
             <span className="text-xs text-slate-400">/día</span>
           </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-orange-100 md:col-span-2">
           <div className="flex items-start gap-4">
              <div className="p-3 bg-red-50 rounded-lg text-red-600">
                <AlertCircle size={24} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-700">Reglas de Pago</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  <strong>Por Hora:</strong> &lt; 3.5h (Todo Extra), &ge; 3.5h (Base + Extra).
                  <br/>
                  <strong>Mensual:</strong> Pago proporcional a los días trabajados (Sueldo / 30 * Días).
                  <br/>
                  <span className="text-orange-600 italic">Multas aplicables para ambos casos por incumplimiento.</span>
                </p>
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-orange-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-6">Horas por Empleado</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={employeeStats} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                <Tooltip 
                  cursor={{fill: '#fff7ed'}}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number) => [`${value.toFixed(2)} h`, 'Horas']}
                />
                <Bar dataKey="hours" name="Horas" radius={[4, 4, 0, 0]} barSize={40}>
                  {employeeStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getRoleColorHex(entry.role)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-orange-100 overflow-hidden">
          <h3 className="text-lg font-semibold text-slate-800 mb-6">Nómina y Pagos</h3>
          <div className="overflow-y-auto max-h-80 pr-2 space-y-3">
             {employeeStats.sort((a,b) => b.totalCost - a.totalCost).map(emp => (
               <div key={emp.id} className="flex flex-col p-3 rounded-lg border border-slate-100 hover:bg-orange-50 transition-colors gap-3">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-10 rounded-full" style={{ backgroundColor: getRoleColorHex(emp.role) }}></div>
                      <div>
                        <p className="font-semibold text-slate-800 flex items-center gap-2">
                           {emp.fullName}
                           {emp.paymentType === 'MONTHLY' && (
                             <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded flex items-center gap-1">
                               <Calendar size={8} /> Mensual
                             </span>
                           )}
                        </p>
                        <p className="text-xs text-slate-500">
                          {emp.daysWorked} turnos • {emp.hours.toFixed(2)}h totales
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-slate-800">Bs {emp.totalCost.toFixed(2)}</p>
                      {emp.totalDiscountAmount > 0 && (
                        <p className="text-xs text-red-500 font-medium">-Bs {emp.totalDiscountAmount.toFixed(2)} desc.</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 border-dashed">
                    <button 
                      onClick={() => {
                        setSelectedEmployeeForDiscount(emp.id);
                        setTempDiscount({ 
                           amount: '', 
                           reason: 'Falta / Incumplimiento',
                           date: new Date().toISOString().split('T')[0]
                        });
                      }}
                      className="text-xs px-3 py-1 bg-slate-100 text-slate-600 rounded-full hover:bg-slate-200 transition-colors flex items-center gap-1"
                    >
                      <AlertCircle size={12} />
                      Multas / Faltas
                    </button>

                    <button 
                      onClick={() => setTicketEmployeeId(emp.id)}
                      className="text-xs px-3 py-1 bg-blue-50 text-blue-600 rounded-full hover:bg-blue-100 transition-colors flex items-center gap-1"
                    >
                      <Banknote size={12} />
                      Ver Boleta
                    </button>
                    
                    <button 
                      onClick={() => handleShareWhatsApp(emp)}
                      className="text-xs px-3 py-1 bg-green-50 text-green-600 rounded-full hover:bg-green-100 transition-colors flex items-center gap-1"
                    >
                      <Share2 size={12} />
                      WhatsApp
                    </button>
                  </div>
               </div>
             ))}
          </div>
        </div>
      </div>

      {/* Discount / Penalty Modal */}
      {selectedEmployeeForDiscount && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] backdrop-blur-sm"
          onClick={() => setSelectedEmployeeForDiscount(null)}
        >
          <div 
            className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl animate-fade-in-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-4">
               <div>
                  <h3 className="text-lg font-bold text-slate-800">Registro de Incidencias</h3>
                  <p className="text-xs text-slate-500">Empleado: {getSelectedEmpName()}</p>
               </div>
               <button onClick={() => setSelectedEmployeeForDiscount(null)} className="text-slate-400 hover:text-slate-600">
                  <X size={20} />
               </button>
            </div>
            
            {/* Add New Penalty Form */}
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-100 space-y-3 mb-4">
              <h4 className="text-xs font-bold text-orange-800 uppercase">Nueva Multa / Falta</h4>
              <div className="grid grid-cols-2 gap-3">
                 <div>
                    <label className="block text-xs text-slate-600 mb-1">Fecha</label>
                    <input 
                      type="date"
                      className="w-full border border-slate-300 rounded p-1.5 text-sm outline-none focus:border-red-500"
                      value={tempDiscount.date}
                      onChange={e => setTempDiscount({...tempDiscount, date: e.target.value})}
                    />
                 </div>
                 <div>
                    <label className="block text-xs text-slate-600 mb-1">Monto (Bs)</label>
                    <input 
                      type="number"
                      min="0"
                      placeholder="0.00"
                      step="0.10"
                      className="w-full border border-slate-300 rounded p-1.5 text-sm outline-none focus:border-red-500"
                      value={tempDiscount.amount}
                      onChange={e => setTempDiscount({...tempDiscount, amount: e.target.value})}
                    />
                 </div>
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Motivo</label>
                <input 
                  type="text"
                  placeholder="Ej: Llegada tarde, uniformes, incumplimiento horario..."
                  className="w-full border border-slate-300 rounded p-1.5 text-sm outline-none focus:border-red-500"
                  value={tempDiscount.reason}
                  onChange={e => setTempDiscount({...tempDiscount, reason: e.target.value})}
                />
              </div>
              <button 
                onClick={handleAddPenalty}
                className="w-full bg-red-600 text-white text-sm font-medium py-2 rounded hover:bg-red-700 transition-colors"
              >
                Registrar Multa
              </button>
            </div>

            {/* List of Existing Penalties */}
            <div>
               <h4 className="text-xs font-bold text-slate-500 uppercase mb-2 border-b pb-1">Historial Semana Actual</h4>
               {currentEmpDiscounts.length === 0 ? (
                 <p className="text-sm text-slate-400 italic text-center py-4">Sin incidencias registradas.</p>
               ) : (
                 <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {currentEmpDiscounts.map(d => (
                       <div key={d.id} className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100 text-sm">
                          <div>
                             <p className="font-medium text-slate-700">{d.reason}</p>
                             <p className="text-xs text-slate-400">{d.date}</p>
                          </div>
                          <div className="flex items-center gap-3">
                             <span className="font-bold text-red-600">- Bs {d.amount.toFixed(2)}</span>
                             <button 
                               onClick={() => onRemoveDiscount(d.id)}
                               className="text-slate-400 hover:text-red-500"
                             >
                                <Trash2 size={14} />
                             </button>
                          </div>
                       </div>
                    ))}
                 </div>
               )}
            </div>
          </div>
        </div>
      )}

      {/* Pay Slip / Ticket Modal */}
      {ticketData && (
        <div 
          className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] backdrop-blur-sm p-4 overflow-y-auto"
          onClick={() => setTicketEmployeeId(null)}
        >
          <div 
            className="relative animate-fade-in-up w-full max-w-sm"
            onClick={e => e.stopPropagation()}
          >
             
             {/* The Ticket Itself */}
             <div ref={ticketRef} className="bg-[#fffbeb] w-full mx-auto p-6 shadow-2xl text-slate-800 font-mono text-sm relative rounded-sm">
                
                {/* Close Button Inside Paper for better Mobile UX */}
                <button 
                  onClick={() => setTicketEmployeeId(null)}
                  className="absolute top-2 right-2 text-red-400 hover:text-red-600 z-10 p-1"
                >
                  <X size={20} />
                </button>

                {/* Decorative Jagged Top */}
                <div 
                  className="absolute top-0 left-0 w-full h-4 bg-[#fffbeb]"
                  style={{
                    background: "linear-gradient(135deg, transparent 75%, #333 75%) 0 50%, linear-gradient(45deg, transparent 75%, #333 75%) 0 50%",
                    backgroundSize: "20px 20px",
                    backgroundRepeat: "repeat-x",
                    marginTop: "-10px",
                    opacity: 0.1 
                  }}
                ></div>

                <div className="text-center mb-6 border-b-2 border-dashed border-slate-300 pb-4">
                  <div className="inline-flex justify-center items-center bg-yellow-500 text-white p-2 rounded-full mb-2">
                    <UtensilsCrossed size={20} />
                  </div>
                  <h2 className="text-xl font-bold text-red-600 uppercase tracking-widest">Doña Candy</h2>
                  <p className="text-xs text-slate-500">BOLETA DE PAGO SEMANAL</p>
                  <p className="text-xs text-slate-400 mt-1">Fecha de Emisión: {new Date().toLocaleDateString('es-BO')}</p>
                </div>

                <div className="mb-6 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Empleado:</span>
                    <span className="font-bold uppercase">{ticketData.fullName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Rol:</span>
                    <span>{ticketData.role}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Contrato:</span>
                    <span>{ticketData.paymentType === 'MONTHLY' ? 'Mensual' : 'Por Horas'}</span>
                  </div>
                </div>

                <div className="mb-4">
                   <h3 className="text-xs font-bold uppercase border-b border-slate-300 mb-2 pb-1">Ingresos</h3>
                   <table className="w-full">
                    <tbody className="divide-y divide-slate-200">
                        <tr>
                        <td className="py-2">
                            {ticketData.paymentType === 'MONTHLY' ? (
                                <>
                                    <div className="font-semibold">Salario Mensual (Proporcional)</div>
                                    <div className="text-xs text-slate-500">
                                        Calculado sobre Bs {ticketData.monthlySalary?.toLocaleString()}/mes
                                        <br/>
                                        {ticketData.daysWorked} días trabajados
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="font-semibold">Salario Base/Extra</div>
                                    <div className="text-xs text-slate-500">{ticketData.hours.toFixed(2)} hrs trabajadas</div>
                                </>
                            )}
                        </td>
                        <td className="py-2 text-right">Bs {ticketData.salaryCost.toFixed(2)}</td>
                        </tr>
                        <tr>
                        <td className="py-2">
                            <div className="font-semibold">Pasajes</div>
                            <div className="text-xs text-slate-500">{ticketData.daysWorked} días x {transportRate}</div>
                        </td>
                        <td className="py-2 text-right">Bs {ticketData.transportCost.toFixed(2)}</td>
                        </tr>
                    </tbody>
                   </table>
                   <div className="flex justify-between items-center mt-2 pt-2 border-t border-slate-200">
                      <span className="font-bold text-slate-600">Subtotal Ingresos</span>
                      <span className="font-bold">Bs {(ticketData.salaryCost + ticketData.transportCost).toFixed(2)}</span>
                   </div>
                </div>

                {ticketData.totalDiscountAmount > 0 && (
                   <div className="mb-4 bg-red-50 p-2 rounded border border-red-100">
                     <h3 className="text-xs font-bold uppercase border-b border-red-200 mb-2 pb-1 text-red-800">Deducciones / Multas</h3>
                     <table className="w-full text-red-700">
                        <tbody>
                            {ticketData.discounts.map((d: Discount, idx: number) => (
                                <tr key={idx}>
                                    <td className="py-1">
                                        <div className="font-medium text-xs">{d.reason}</div>
                                        <div className="text-[10px] opacity-75">{d.date}</div>
                                    </td>
                                    <td className="py-1 text-right font-medium">- Bs {d.amount.toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                     </table>
                     <div className="flex justify-between items-center mt-2 pt-2 border-t border-red-200">
                        <span className="font-bold text-xs uppercase">Total Deducciones</span>
                        <span className="font-bold">- Bs {ticketData.totalDiscountAmount.toFixed(2)}</span>
                     </div>
                   </div>
                )}

                <div className="border-t-2 border-dashed border-slate-800 pt-4 mt-4">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>TOTAL LIQUIDO</span>
                    <span>Bs {ticketData.totalCost.toFixed(2)}</span>
                  </div>
                </div>

                <div className="mt-8 text-center">
                  <p className="text-xs text-slate-400">Gracias por tu trabajo en Doña Candy</p>
                  <p className="text-[10px] text-slate-300 mt-1 uppercase">Lo hacemos como en casa</p>
                </div>
             </div>

             <div className="mt-4 flex gap-2 justify-center">
                <button 
                  onClick={handleDownloadImage}
                  className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-full hover:bg-black transition-colors shadow-lg"
                >
                  <Download size={18} />
                  <span>Descargar Boleta (Viernes)</span>
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};
