
import React, { useState, useRef } from 'react';
import { UserPlus, Trash2, Edit2, Banknote, Phone, Image as ImageIcon, Upload, X, Calendar } from 'lucide-react';
import { Employee, EmployeeRole, PaymentType } from '../types';
import { getRoleColor } from '../constants';

interface EmployeeListProps {
  employees: Employee[];
  onAddEmployee: (emp: Employee) => void;
  onEditEmployee: (emp: Employee) => void;
  onDeleteEmployee: (id: string) => void;
}

export const EmployeeList: React.FC<EmployeeListProps> = ({ employees, onAddEmployee, onEditEmployee, onDeleteEmployee }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Ref for the hidden file input
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<Partial<Employee>>({
    role: EmployeeRole.WAITER,
    maxHoursPerWeek: 40,
    paymentType: 'HOURLY',
    hourlyRateBase: 20,
    hourlyRateOvertime: 30,
    monthlySalary: 2500,
    phone: '',
    photoUrl: ''
  });

  const resetForm = () => {
    setFormData({ 
      role: EmployeeRole.WAITER, 
      maxHoursPerWeek: 40, 
      name: '', 
      email: '',
      phone: '',
      photoUrl: '',
      paymentType: 'HOURLY',
      hourlyRateBase: 20,
      hourlyRateOvertime: 30,
      monthlySalary: 2500
    });
    setEditingId(null);
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    setFormData({ ...emp });
    setEditingId(emp.id);
    setIsModalOpen(true);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setFormData(prev => ({ ...prev, photoUrl: '' }));
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.role) {
      const employeeData = {
        id: editingId || crypto.randomUUID(),
        name: formData.name,
        email: formData.email,
        phone: formData.phone || '',
        photoUrl: formData.photoUrl || '',
        role: formData.role,
        maxHoursPerWeek: formData.maxHoursPerWeek || 40,
        paymentType: formData.paymentType || 'HOURLY',
        hourlyRateBase: formData.hourlyRateBase || 0,
        hourlyRateOvertime: formData.hourlyRateOvertime || 0,
        monthlySalary: formData.monthlySalary || 0
      };

      if (editingId) {
        onEditEmployee(employeeData);
      } else {
        onAddEmployee(employeeData);
      }
      
      setIsModalOpen(false);
      resetForm();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Plantilla de Empleados</h2>
        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors shadow-md shadow-red-200"
        >
          <UserPlus size={18} />
          <span>Nuevo Empleado</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {employees.map((emp) => (
          <div key={emp.id} className="bg-white p-5 rounded-xl shadow-sm border border-orange-100 flex flex-col justify-between group hover:shadow-md transition-shadow relative overflow-hidden">
             {/* Decorative Background for Role */}
             <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full opacity-10 ${getRoleColor(emp.role)}`}></div>

            <div>
              <div className="flex items-start gap-4 mb-4">
                {/* Photo or Fallback Avatar */}
                <div className={`w-16 h-16 rounded-full flex-shrink-0 border-2 border-white shadow-md overflow-hidden ${!emp.photoUrl ? getRoleColor(emp.role).split(' ')[0] : 'bg-slate-100'}`}>
                   {emp.photoUrl ? (
                     <img src={emp.photoUrl} alt={emp.name} className="w-full h-full object-cover" />
                   ) : (
                     <div className="w-full h-full flex items-center justify-center text-2xl font-bold opacity-40">
                       {emp.name.charAt(0)}
                     </div>
                   )}
                </div>

                <div className="flex-1 min-w-0">
                   <div className="flex justify-between items-start">
                     <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border mb-1 inline-block ${getRoleColor(emp.role)}`}>
                        {emp.role}
                     </span>
                   </div>
                   <h3 className="text-lg font-bold text-slate-800 truncate leading-tight">{emp.name}</h3>
                   <div className="flex items-center gap-1.5 text-slate-500 mt-1">
                      <Phone size={12} />
                      <span className="text-xs">{emp.phone || 'Sin celular'}</span>
                   </div>
                </div>
              </div>
              
              <div className="space-y-2 mt-2 bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="text-sm text-slate-600 flex justify-between border-b border-slate-200 pb-2 border-dashed">
                  <span className="text-xs">Email</span>
                  <span className="font-medium text-xs truncate max-w-[150px]">{emp.email}</span>
                </div>
                
                {emp.paymentType === 'MONTHLY' ? (
                   <div className="text-sm text-slate-600 flex justify-between items-center pt-1">
                      <div className="flex items-center gap-1 text-slate-400">
                          <Calendar size={14} />
                          <span className="text-xs">Mensual</span>
                      </div>
                      <div className="text-right leading-tight">
                          <span className="font-bold text-slate-800 block text-sm">Bs {emp.monthlySalary?.toLocaleString()}</span>
                          <span className="text-[10px] text-slate-400">Sueldo Fijo</span>
                      </div>
                   </div>
                ) : (
                  <div className="text-sm text-slate-600 flex justify-between items-center pt-1">
                     <div className="flex items-center gap-1 text-slate-400">
                        <Banknote size={14} />
                        <span className="text-xs">Por Hora</span>
                     </div>
                     <div className="text-right leading-tight">
                        <span className="font-bold text-slate-700 block text-sm">Bs {emp.hourlyRateBase}</span>
                        <span className="text-[10px] text-slate-400">1ras 3.5h</span>
                     </div>
                     <div className="w-px h-6 bg-slate-200 mx-1"></div>
                     <div className="text-right leading-tight">
                        <span className="font-bold text-red-600 block text-sm">Bs {emp.hourlyRateOvertime}</span>
                        <span className="text-[10px] text-slate-400">Extras</span>
                     </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="mt-4 flex justify-end gap-2">
               <button 
                onClick={() => handleOpenEdit(emp)}
                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-1"
                title="Editar"
              >
                <Edit2 size={16} />
                <span className="text-xs font-medium">Editar</span>
              </button>
               <button 
                onClick={() => onDeleteEmployee(emp.id)}
                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-1"
                title="Eliminar"
              >
                <Trash2 size={16} />
                <span className="text-xs font-medium">Borrar</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 overflow-y-auto py-10 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl my-auto border-t-4 border-red-500 animate-fade-in-up">
            <h3 className="text-xl font-bold mb-4 text-slate-800">
              {editingId ? 'Editar Empleado' : 'Agregar Empleado'}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {/* Photo Upload Section */}
                <div className="col-span-2 flex flex-col items-center justify-center mb-2">
                    <input 
                        type="file" 
                        accept="image/*" 
                        ref={fileInputRef}
                        onChange={handleImageUpload}
                        className="hidden" 
                    />
                    
                    {formData.photoUrl ? (
                        <div className="relative group">
                            <img 
                                src={formData.photoUrl} 
                                alt="Preview" 
                                className="w-24 h-24 rounded-full object-cover border-4 border-orange-100 shadow-md"
                            />
                            <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity gap-2">
                                <button 
                                    type="button"
                                    onClick={() => fileInputRef.current?.click()}
                                    className="text-white p-1 hover:text-orange-200"
                                    title="Cambiar"
                                >
                                    <Edit2 size={16} />
                                </button>
                                <button 
                                    type="button"
                                    onClick={handleRemoveImage}
                                    className="text-white p-1 hover:text-red-400"
                                    title="Eliminar"
                                >
                                    <X size={16} />
                                </button>
                            </div>
                        </div>
                    ) : (
                        <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="w-24 h-24 rounded-full bg-slate-50 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:border-red-400 hover:text-red-500 hover:bg-red-50 transition-all"
                        >
                            <Upload size={24} />
                            <span className="text-[10px] font-medium mt-1">Subir Foto</span>
                        </button>
                    )}
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Nombre Completo</label>
                  <input
                    type="text"
                    required
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-red-500 outline-none"
                    value={formData.name || ''}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Celular</label>
                  <input
                    type="text"
                    placeholder="Ej: 70012345"
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-red-500 outline-none"
                    value={formData.phone || ''}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                  />
                </div>

                <div>
                   <label className="block text-sm font-medium text-slate-700 mb-1">Rol</label>
                   <select
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-red-500 outline-none bg-white"
                    value={formData.role}
                    onChange={e => setFormData({...formData, role: e.target.value as EmployeeRole})}
                  >
                    {Object.values(EmployeeRole).map(role => (
                      <option key={role} value={role}>{role}</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    required
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-red-500 outline-none"
                    value={formData.email || ''}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>

              <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 space-y-4 mt-2">
                 <div className="flex items-center gap-2 mb-2">
                    <Banknote size={18} className="text-orange-600" />
                    <p className="text-sm font-bold text-orange-800 uppercase tracking-wider">Configuración de Pago</p>
                 </div>
                 
                 {/* Payment Type Toggle */}
                 <div className="flex gap-2 p-1 bg-slate-200 rounded-lg mb-3">
                    <button
                        type="button"
                        onClick={() => setFormData({...formData, paymentType: 'HOURLY'})}
                        className={`flex-1 text-xs font-bold py-1.5 rounded-md transition-all ${
                            formData.paymentType === 'HOURLY' 
                            ? 'bg-white text-slate-800 shadow-sm' 
                            : 'text-slate-500 hover:text-slate-700'
                        }`}
                    >
                        Por Horas
                    </button>
                    <button
                        type="button"
                        onClick={() => setFormData({...formData, paymentType: 'MONTHLY'})}
                        className={`flex-1 text-xs font-bold py-1.5 rounded-md transition-all ${
                            formData.paymentType === 'MONTHLY' 
                            ? 'bg-white text-slate-800 shadow-sm' 
                            : 'text-slate-500 hover:text-slate-700'
                        }`}
                    >
                        Mensual
                    </button>
                 </div>

                 {formData.paymentType === 'HOURLY' ? (
                     <div className="grid grid-cols-2 gap-4 animate-fade-in">
                        <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Tarifa Base (1ras 3.5h)</label>
                        <div className="relative">
                            <span className="absolute left-3 top-2 text-slate-400 text-sm">Bs</span>
                            <input
                            type="number"
                            required
                            min="0"
                            step="0.5"
                            className="w-full border border-slate-300 rounded-lg p-2 pl-9 focus:ring-2 focus:ring-red-500 outline-none font-bold text-slate-700"
                            value={formData.hourlyRateBase}
                            onChange={e => setFormData({...formData, hourlyRateBase: parseFloat(e.target.value)})}
                            />
                        </div>
                        </div>
                        <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Tarifa Extra ({'>'}3.5h)</label>
                        <div className="relative">
                            <span className="absolute left-3 top-2 text-slate-400 text-sm">Bs</span>
                            <input
                            type="number"
                            required
                            min="0"
                            step="0.5"
                            className="w-full border border-slate-300 rounded-lg p-2 pl-9 focus:ring-2 focus:ring-red-500 outline-none font-bold text-red-600"
                            value={formData.hourlyRateOvertime}
                            onChange={e => setFormData({...formData, hourlyRateOvertime: parseFloat(e.target.value)})}
                            />
                        </div>
                        </div>
                     </div>
                 ) : (
                    <div className="animate-fade-in">
                        <label className="block text-xs font-medium text-slate-700 mb-1">Sueldo Mensual Fijo</label>
                        <div className="relative">
                            <span className="absolute left-3 top-2 text-slate-400 text-sm">Bs</span>
                            <input
                            type="number"
                            required
                            min="0"
                            step="1"
                            className="w-full border border-slate-300 rounded-lg p-2 pl-9 focus:ring-2 focus:ring-red-500 outline-none font-bold text-slate-700"
                            value={formData.monthlySalary}
                            onChange={e => setFormData({...formData, monthlySalary: parseFloat(e.target.value)})}
                            />
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">
                            * Se calculará el pago diario dividiendo entre 30 días.
                        </p>
                    </div>
                 )}

                 <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Horas Esperadas (Semanales)</label>
                    <input
                      type="number"
                      required
                      min="1"
                      max="80"
                      className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-red-500 outline-none"
                      value={formData.maxHoursPerWeek || 40}
                      onChange={e => setFormData({...formData, maxHoursPerWeek: parseInt(e.target.value)})}
                    />
                 </div>
              </div>

              <div className="flex gap-3 mt-6 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 shadow-lg shadow-red-200 font-medium"
                >
                  {editingId ? 'Guardar Cambios' : 'Crear Empleado'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
