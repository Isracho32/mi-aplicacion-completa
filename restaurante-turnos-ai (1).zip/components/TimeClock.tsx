
import React, { useState, useEffect } from 'react';
import { Clock, LogIn, LogOut, Coffee, CheckCircle2, RotateCcw, AlertTriangle } from 'lucide-react';
import { Employee, TimeLog } from '../types';
import { getRoleColor } from '../constants';

interface TimeClockProps {
  employees: Employee[];
  timeLogs: TimeLog[];
  onClockIn: (employeeId: string) => void;
  onClockOut: (employeeId: string) => void;
  onCancelClockIn: (employeeId: string) => void;
}

export const TimeClock: React.FC<TimeClockProps> = ({ 
  employees, 
  timeLogs, 
  onClockIn, 
  onClockOut,
  onCancelClockIn
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getActiveLog = (empId: string) => timeLogs.find(log => log.employeeId === empId && !log.clockOut);
  
  // Check if employee has ALREADY finished a shift today
  const hasFinishedToday = (empId: string) => {
    return timeLogs.some(log => {
      if (log.employeeId !== empId || !log.clockOut) return false;
      
      const logDate = new Date(log.clockOut);
      const today = new Date();
      
      return (
        logDate.getDate() === today.getDate() &&
        logDate.getMonth() === today.getMonth() &&
        logDate.getFullYear() === today.getFullYear()
      );
    });
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col items-center justify-center py-8 bg-slate-900 rounded-2xl text-white shadow-xl border-b-4 border-red-500">
        <Clock size={48} className="text-red-500 mb-4" />
        <h2 className="text-5xl font-mono font-bold tracking-wider mb-2">
          {currentTime.toLocaleTimeString('es-BO', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
        </h2>
        <p className="text-slate-400 text-lg">
          {currentTime.toLocaleDateString('es-BO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {employees.map(emp => {
          const activeLog = getActiveLog(emp.id);
          const finishedToday = hasFinishedToday(emp.id);
          const isWorking = !!activeLog;

          let canCancel = false;
          let minsElapsed = 0;

          if (isWorking && activeLog) {
             const diffMs = currentTime.getTime() - activeLog.clockIn.getTime();
             minsElapsed = Math.floor(diffMs / 60000);
             // Allow cancel within first 10 minutes
             canCancel = minsElapsed <= 10;
          }

          return (
            <div 
              key={emp.id} 
              className={`relative overflow-hidden bg-white rounded-xl shadow-sm border transition-all duration-300 ${
                isWorking 
                  ? 'border-emerald-500 shadow-md ring-1 ring-emerald-500/20' 
                  : finishedToday 
                    ? 'border-slate-200 bg-slate-50'
                    : 'border-orange-100 hover:border-orange-300'
              }`}
            >
              <div className="p-5 flex flex-col h-full">
                <div className="flex justify-between items-start mb-4">
                   <div className="flex flex-col">
                      <span className="font-bold text-lg text-slate-800">{emp.name}</span>
                      <span className={`text-xs mt-1 px-2 py-0.5 rounded-full w-fit border ${getRoleColor(emp.role)}`}>
                        {emp.role}
                      </span>
                   </div>
                   {isWorking && (
                     <span className="flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-3 w-3 rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                     </span>
                   )}
                   {finishedToday && (
                     <CheckCircle2 className="text-slate-400" size={24} />
                   )}
                </div>

                <div className="flex-1 flex items-center justify-center py-4">
                  {isWorking ? (
                    <div className="text-center">
                      <p className="text-xs text-slate-500 uppercase font-semibold mb-1">Entrada</p>
                      <p className="text-2xl font-mono text-emerald-600 font-bold">
                        {activeLog.clockIn.toLocaleTimeString('es-BO', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">Jornada en curso</p>
                      {canCancel && (
                         <div className="mt-2 text-[10px] text-orange-500 flex items-center justify-center gap-1 bg-orange-50 px-2 py-1 rounded">
                           <AlertTriangle size={10} />
                           <span>Modo corrección ({10 - minsElapsed} min)</span>
                         </div>
                      )}
                    </div>
                  ) : finishedToday ? (
                     <div className="text-center opacity-60">
                       <p className="text-lg font-bold text-slate-600">Jornada Finalizada</p>
                       <p className="text-xs text-slate-400 mt-1">Hasta mañana</p>
                    </div>
                  ) : (
                    <div className="text-center opacity-50">
                       <Coffee size={32} className="mx-auto text-slate-300 mb-2" />
                       <p className="text-sm text-slate-400">Fuera de turno</p>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100">
                  {isWorking ? (
                    <div className="space-y-2">
                       {/* Standard Clock Out */}
                       <button
                        onClick={() => onClockOut(emp.id)}
                        className="w-full flex items-center justify-center gap-2 bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700 py-2.5 rounded-lg font-medium transition-colors"
                      >
                        <LogOut size={18} />
                        Marcar Salida
                      </button>
                      
                      {/* Undo / Cancel Button (Only if < 10 mins) */}
                      {canCancel && (
                        <button
                          onClick={() => onCancelClockIn(emp.id)}
                          className="w-full flex items-center justify-center gap-2 bg-yellow-100 text-yellow-700 hover:bg-yellow-200 py-1.5 rounded-lg text-xs font-medium transition-colors"
                        >
                          <RotateCcw size={14} />
                          Anular Entrada (Error)
                        </button>
                      )}
                    </div>
                  ) : finishedToday ? (
                    <div className="w-full text-center py-2.5 text-xs text-slate-400 font-medium bg-slate-100 rounded-lg select-none">
                      Asistencia Registrada
                    </div>
                  ) : (
                    <button
                      onClick={() => onClockIn(emp.id)}
                      className="w-full flex items-center justify-center gap-2 bg-slate-900 text-white hover:bg-slate-800 py-2.5 rounded-lg font-medium transition-colors"
                    >
                      <LogIn size={18} />
                      Marcar Entrada
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
